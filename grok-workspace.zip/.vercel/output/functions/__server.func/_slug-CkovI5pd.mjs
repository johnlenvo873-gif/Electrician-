import { b as Link, q as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { a as banners, d as tradeBySlug, p as useI18n } from "./_ssr/i18n-Bpg8-YJB.mjs";
import { n as Page } from "./_ssr/site-chrome-BsLshem2.mjs";
import { n as Route } from "./_ssr/router-CM_JRMzg.mjs";
import { a as JobList, c as TradeStrip, t as BannerList } from "./_ssr/banners-Cg-qkRB-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-CkovI5pd.js
var import_jsx_runtime = require_jsx_runtime();
function TradePage() {
	const { slug } = Route.useParams();
	const { lang, copy } = useI18n();
	const trade = tradeBySlug(slug);
	if (!trade) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-xl px-4 py-24 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: copy.notFoundTitle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: copy.notFoundBody
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/services",
				className: "mt-6 inline-flex h-12 items-center rounded-full bg-copper px-5 font-semibold text-paper",
				children: copy.services
			})
		]
	}) });
	const text = trade[lang];
	const related = banners.filter((banner) => banner.trade === trade.slug);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "pb-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "bg-ink text-paper lg:grid lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative min-h-72",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: trade.image,
						alt: "",
						className: "absolute inset-0 h-full w-full object-cover"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col justify-center px-5 py-10 sm:px-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold",
							children: text.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-4 block h-1 w-12 rounded-full bg-copper" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-4 font-display text-4xl sm:text-5xl",
							children: text.headline
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-xl text-lg text-paper/80",
							children: text.lede
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 font-display text-3xl tabular-nums",
							children: [
								copy.from,
								" ",
								trade.from
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-paper/70",
							children: copy.priceNote
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/book",
							search: { service: trade.slug },
							className: "mt-6 inline-flex h-12 w-fit items-center rounded-full bg-copper px-5 font-semibold text-paper hover:bg-copper-deep",
							children: copy.bookThis
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-6xl px-4 py-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl",
					children: copy.included
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JobList, { jobs: text.jobs })
				})]
			}),
			related.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-6xl px-4 pb-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-6 font-display text-3xl",
					children: copy.related
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BannerList, { items: related })]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mx-auto max-w-6xl px-4 pb-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TradeStrip, { except: trade.slug })
			})
		]
	}) });
}
//#endregion
export { TradePage as component };
