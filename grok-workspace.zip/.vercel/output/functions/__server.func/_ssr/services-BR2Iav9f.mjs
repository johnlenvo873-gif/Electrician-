import { q as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as trades, p as useI18n } from "./i18n-Bpg8-YJB.mjs";
import { n as Page } from "./site-chrome-BsLshem2.mjs";
import { s as TradeCard } from "./banners-Cg-qkRB-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services-BR2Iav9f.js
var import_jsx_runtime = require_jsx_runtime();
function ServicesHome() {
	const { copy } = useI18n();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-12 pb-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold text-copper",
				children: "gharline.com"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 max-w-3xl font-display text-4xl sm:text-6xl",
				children: copy.servicesTitle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-2xl text-lg text-muted",
				children: copy.servicesLede
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-4 md:grid-cols-2",
				children: trades.map((trade) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TradeCard, { trade }, trade.slug))
			})
		]
	}) });
}
//#endregion
export { ServicesHome as component };
