import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, q as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/i18n-Bpg8-YJB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DOMAIN = "gharline.com";
var PHONE_DISPLAY = "021 111 442 700";
var PHONE_TEL = "+9221111442700";
var ui = {
	en: {
		book: "Book a visit",
		call: "Call the desk",
		home: "Home",
		services: "Services",
		offers: "Banners",
		menu: "Menu",
		close: "Close",
		from: "From",
		seeTrade: "Open this trade",
		bookThis: "Book this trade",
		included: "What we actually fix",
		howTitle: "How a visit works",
		howLede: "No surprise invoice. You hear the number before a tool comes out.",
		citiesTitle: "Eight cities on the line",
		citiesLede: "Metro crews roll the same day inside city limits. Outside the ring road, we book the next morning window.",
		reviewsTitle: "From houses we have already been in",
		faqTitle: "Before you call",
		allBanners: "Every live banner",
		bannerLede: "Seasonal work, night call-outs, and package rates. Tap one to book that job.",
		notFoundTitle: "This page is not on the line",
		notFoundBody: "The address is wrong, or that trade is not listed yet.",
		backHome: "Back to GharLine",
		name: "Your name",
		phone: "Mobile number",
		city: "City",
		service: "Trade",
		when: "When should we come",
		note: "What is wrong",
		submit: "Send the request",
		sending: "Sending",
		successTitle: "Request is on the desk",
		ticket: "Ticket",
		confirmNote: "No payment on this page. The desk calls this number to lock the window and read the quote.",
		onDevice: "Saved on this device only.",
		recent: "Requests from this device",
		needName: "Write your name.",
		needPhone: "Use a mobile like 03xx or +92.",
		needCity: "Pick a city.",
		needService: "Pick a trade.",
		needNote: "Tell us the fault in a sentence.",
		visitNote: "Visit fee Rs 499, taken off the bill if you go ahead. Parts stay on the written quote.",
		choose: "Choose",
		priceNote: "Labour from this figure. Parts are extra and shown before we fit them.",
		related: "Banners for this trade",
		otherTrades: "The other three trades",
		promiseTitle: "The line we keep",
		coverageLabel: "Coverage",
		domainLine: "The home desk",
		heroKicker: "Electrician · Appliances · Plumber · Pest",
		heroTitle: "The only line your house needs.",
		heroLede: "One desk for power, machines, pipes, and pests. Licensed techs in eight cities, a written quote, and a 30-day cover on the work.",
		servicesTitle: "Four trades. Plenty of banners.",
		servicesLede: "Pick the fault. Each banner opens the jobs, the starting rate, and a booking for that crew.",
		emergencyKicker: "Night desk",
		emergencyTitle: "Lights out, a burst pipe, or something moving in the kitchen.",
		emergencyBody: "The night line stays open. A tech is dispatched with the same quote rule — you approve, then we open the toolbox.",
		closingTitle: "Put the house back on the line.",
		closingBody: "Tell us the city and the fault. We call back with a window, not a chatbot.",
		steps: [
			{
				t: "Call or book",
				d: "Name the trade and what stopped working. A person answers."
			},
			{
				t: "Quote on the doorstep",
				d: "The tech writes the labour and parts. You can say no."
			},
			{
				t: "Fix, then cover",
				d: "Workmanship is covered for 30 days. We come back if it fails."
			}
		],
		promises: [
			{
				t: "Quote first",
				d: "Nothing starts until you nod at the number."
			},
			{
				t: "Same-day cities",
				d: "Inside Karachi, Lahore, and Islamabad rings when the board is open."
			},
			{
				t: "30-day cover",
				d: "If our work fails, the return visit is on us."
			},
			{
				t: "Parts you can see",
				d: "Old part comes out. New part is in your hand before it goes in."
			}
		],
		stats: [
			{
				n: "8",
				l: "Cities"
			},
			{
				n: "4",
				l: "Trades"
			},
			{
				n: "30",
				l: "Day cover"
			},
			{
				n: "24/7",
				l: "Night line"
			}
		]
	},
	ur: {
		book: "وزٹ بک کریں",
		call: "ڈیسک کو کال",
		home: "ہوم",
		services: "سروسز",
		offers: "بینرز",
		menu: "مینو",
		close: "بند کریں",
		from: "شروع",
		seeTrade: "یہ سروس کھولیں",
		bookThis: "یہ سروس بک کریں",
		included: "ہم اصل میں کیا ٹھیک کرتے ہیں",
		howTitle: "وزٹ کیسے ہوتا ہے",
		howLede: "اچانک بل نہیں۔ اوزار نکلنے سے پہلے نمبر سن لیں۔",
		citiesTitle: "آٹھ شہر لائن پر",
		citiesLede: "شہر کی حد میں اسی دن۔ رنگ روڈ کے باہر اگلی صبح کی ونڈو۔",
		reviewsTitle: "جن گھروں میں ہم جا چکے",
		faqTitle: "کال سے پہلے",
		allBanners: "سارے لائیو بینرز",
		bannerLede: "موسم، رات کی کال، اور پیکیج ریٹ۔ بینر دبائیں، وہی کام بک ہوگا۔",
		notFoundTitle: "یہ صفحہ لائن پر نہیں",
		notFoundBody: "پتہ غلط ہے، یا یہ سروس ابھی درج نہیں۔",
		backHome: "گھر لائن پر واپس",
		name: "آپ کا نام",
		phone: "موبائل نمبر",
		city: "شہر",
		service: "سروس",
		when: "کب آئیں",
		note: "مسئلہ کیا ہے",
		submit: "درخواست بھیجیں",
		sending: "بھیج رہے ہیں",
		successTitle: "درخواست ڈیسک پر پہنچ گئی",
		ticket: "ٹکٹ",
		confirmNote: "اس صفحے پر پیسے نہیں کٹتے۔ ڈیسک اسی نمبر پر کال کر کے وقت اور کوٹ طے کرے گی۔",
		onDevice: "صرف اسی ڈیوائس پر محفوظ ہے۔",
		recent: "اس ڈیوائس کی درخواستیں",
		needName: "نام لکھیں۔",
		needPhone: "03xx یا +92 والا موبائل لکھیں۔",
		needCity: "شہر چنیں۔",
		needService: "سروس چنیں۔",
		needNote: "مسئلہ ایک جملے میں لکھیں۔",
		visitNote: "وزٹ فیس 499 روپے، کام کروانے پر بل میں مائنس۔ پرزے لکھے ہوئے کوٹ پر۔",
		choose: "چنیں",
		priceNote: "یہ مزدوری کی ابتدا ہے۔ پرزے الگ ہیں اور لگانے سے پہلے دکھائے جاتے ہیں۔",
		related: "اسی سروس کے بینرز",
		otherTrades: "باقی تین سروسز",
		promiseTitle: "جو وعدہ ہم رکھتے ہیں",
		coverageLabel: "کوریج",
		domainLine: "گھر کا ڈیسک",
		heroKicker: "الیکٹریشن · اپلائنس · پلمبر · پیسٹ",
		heroTitle: "آپ کے گھر کے لیے ایک ہی لائن۔",
		heroLede: "بجلی، مشینیں، پائپ اور کیڑے — ایک ڈیسک۔ آٹھ شہروں میں تکنیشن، لکھا ہوا کوٹ، اور کام پر تیس دن کی ذمہ داری۔",
		servicesTitle: "چار سروسز۔ بہت سے بینرز۔",
		servicesLede: "خرابی چنیں۔ ہر بینر کام، شروع کا ریٹ، اور اسی کریو کی بکنگ کھولتا ہے۔",
		emergencyKicker: "رات کی ڈیسک",
		emergencyTitle: "بجلی گئی، پائپ پھٹا، یا کچن میں کچھ ہل رہا ہے۔",
		emergencyBody: "رات کی لائن کھلی رہتی ہے۔ وہی قاعدہ: آپ ہاں کہیں، پھر ٹول باکس کھلے گا۔",
		closingTitle: "گھر کو دوبارہ لائن پر لائیں۔",
		closingBody: "شہر اور خرابی بتائیں۔ ہم ونڈو کے ساتھ کال کرتے ہیں، چیٹ بوٹ نہیں۔",
		steps: [
			{
				t: "کال یا بک",
				d: "سروس بتائیں اور کیا رک گیا۔ آدمی جواب دیتا ہے۔"
			},
			{
				t: "دروازے پر کوٹ",
				d: "ٹیکنیشن مزدوری اور پرزے لکھ کر دیتا ہے۔ انکار کر سکتے ہیں۔"
			},
			{
				t: "مرمت، پھر ذمہ داری",
				d: "کام تیس دن کَور ہے۔ خراب ہو تو واپسی ہماری طرف سے۔"
			}
		],
		promises: [
			{
				t: "پہلے کوٹ",
				d: "نمبر پر ہاں کہے بغیر کام شروع نہیں ہوتا۔"
			},
			{
				t: "اسی دن شہر",
				d: "کراچی، لاہور اور اسلام آباد کی حد میں جب بورڈ کھلا ہو۔"
			},
			{
				t: "تیس دن",
				d: "ہمارا کام خراب ہو تو واپسی وزٹ ہمارا۔"
			},
			{
				t: "پرزہ سامنے",
				d: "پرانا پرزہ باہر۔ نیا ہاتھ میں، پھر لگے گا۔"
			}
		],
		stats: [
			{
				n: "8",
				l: "شہر"
			},
			{
				n: "4",
				l: "سروسز"
			},
			{
				n: "30",
				l: "دن کَور"
			},
			{
				n: "24/7",
				l: "رات کی لائن"
			}
		]
	}
};
var cities = [
	{
		en: "Karachi",
		ur: "کراچی"
	},
	{
		en: "Lahore",
		ur: "لاہور"
	},
	{
		en: "Islamabad",
		ur: "اسلام آباد"
	},
	{
		en: "Rawalpindi",
		ur: "راولپنڈی"
	},
	{
		en: "Faisalabad",
		ur: "فیصل آباد"
	},
	{
		en: "Multan",
		ur: "ملتان"
	},
	{
		en: "Peshawar",
		ur: "پشاور"
	},
	{
		en: "Hyderabad",
		ur: "حیدرآباد"
	}
];
var slots = [
	{
		en: "Today — same-day window",
		ur: "آج — اسی دن کی ونڈو"
	},
	{
		en: "Tomorrow morning",
		ur: "کل صبح"
	},
	{
		en: "Tomorrow evening",
		ur: "کل شام"
	},
	{
		en: "This week — call me to pick",
		ur: "اس ہفتے — کال کر کے طے کریں"
	}
];
var trades = [
	{
		slug: "electrician",
		icon: "zap",
		image: "/banners/hero.jpg",
		from: "Rs 1,500",
		en: {
			name: "Electrician",
			short: "Tripping breakers, dead points, fans, geysers, and inverters.",
			headline: "The breaker keeps dropping. The fan hums and sits.",
			lede: "House wiring, DB boards, points, and the small machines that run on them. We do not guess at a live short.",
			jobs: [
				"Breaker and DB faults",
				"New switch, socket, or power point",
				"Ceiling fan and light fitting",
				"Short circuit tracing",
				"Inverter and UPS changeover",
				"Geyser element and thermostat",
				"Door bell, exhaust, and fancy lights",
				"Full-home wiring safety check"
			]
		},
		ur: {
			name: "الیکٹریشن",
			short: "ٹرپنگ، مردہ پوائنٹ، پنکھا، گیزر اور انورٹر۔",
			headline: "بریکر گرتا رہتا ہے۔ پنکھا گنگناتا ہے اور رک جاتا ہے۔",
			lede: "ہاؤس وائرنگ، ڈی بی، پوائنٹ، اور جو مشینیں ان پر چلتی ہیں۔ لائیو شارٹ پر اندازہ نہیں لگاتے۔",
			jobs: [
				"بریکر اور ڈی بی کی خرابی",
				"نیا سوئچ، ساکٹ یا پاور پوائنٹ",
				"سیلنگ فین اور لائٹ فٹنگ",
				"شارٹ سرکٹ ٹریس کرنا",
				"انورٹر اور یو پی ایس چینج اوور",
				"گیزر کا راڈ اور تھرموسٹیٹ",
				"ڈور بیل، ایگزاسٹ اور لائٹس",
				"پورے گھر کی وائرنگ چیک"
			]
		}
	},
	{
		slug: "appliance",
		icon: "washer",
		image: "/banners/appliance.jpg",
		from: "Rs 1,200",
		en: {
			name: "Appliance repair",
			short: "Washers, fridges, ovens, and the AC that quit last night.",
			headline: "The machine has a nameplate. We bring the parts for it.",
			lede: "Major appliances stay in the house. No van-it-away unless the motor is truly finished and you agree.",
			jobs: [
				"Washing machine not spinning or draining",
				"Fridge warm, icing up, or noisy",
				"Microwave and oven faults",
				"Dishwasher leaks and errors",
				"Split AC service and gas",
				"Water dispenser cooling",
				"Tumble dryer belts and heaters",
				"Stabilizer and heavy-load sockets"
			]
		},
		ur: {
			name: "اپلائنس مرمت",
			short: "واشر، فریج، اوون، اور وہ اے سی جو رات کو بند ہو گیا۔",
			headline: "مشین کا نام لکھا ہوتا ہے۔ پرزہ اسی کا لاتے ہیں۔",
			lede: "بڑی مشین گھر میں ہی ٹھیک ہوتی ہے۔ وین میں لے جانا تب جب موٹر واقعی ختم ہو اور آپ ہاں کہیں۔",
			jobs: [
				"واشنگ مشین نہ گھومے یا پانی نہ نکالے",
				"فریج گرم، برف جمع، یا شور",
				"مائیکروویو اور اوون",
				"ڈش واشر لیک اور ایرر",
				"اسپلٹ اے سی سروس اور گیس",
				"واٹر ڈسپنسر ٹھنڈا نہ کرے",
				"ڈرائر کی بیلٹ اور ہیٹر",
				"سٹیبلائزر اور ہیوی ساکٹ"
			]
		}
	},
	{
		slug: "plumber",
		icon: "drops",
		image: "/banners/plumber.jpg",
		from: "Rs 1,000",
		en: {
			name: "Plumber",
			short: "Leaks, choked lines, motors, tanks, and mixer taps.",
			headline: "Water where it should not be. None where it should.",
			lede: "Supply, waste, and the pump that feeds the roof tank. We open the trap before we talk about breaking tiles.",
			jobs: [
				"Kitchen and bath leaks",
				"Blocked drain and floor trap",
				"Commode, flush, and Muslim shower",
				"Mixer tap and concealed stop cock",
				"Overhead tank and ball valve",
				"Motor and pressure pump",
				"Geyser inlet and overflow",
				"Monsoon courtyard drains"
			]
		},
		ur: {
			name: "پلمبر",
			short: "لیک، بند لائن، موٹر، ٹینک اور مکسر۔",
			headline: "پانی وہاں جہاں نہیں ہونا چاہیے۔ وہاں نہیں جہاں ہونا چاہیے۔",
			lede: "سپلائی، ویسٹ، اور چھت کے ٹینک والی موٹر۔ ٹائل توڑنے سے پہلے ٹریپ کھولتے ہیں۔",
			jobs: [
				"کچن اور باتھ کی لیک",
				"بند ڈرین اور فلور ٹریپ",
				"کموڈ، فلش اور مسلم شاور",
				"مکسر اور کنسیلد سٹاپ کاک",
				"اوورہیڈ ٹینک اور بال والو",
				"موٹر اور پریشر پمپ",
				"گیزر کی انلیٹ اور اوور فلو",
				"مون سون میں صحن کی ڈرین"
			]
		}
	},
	{
		slug: "pest",
		icon: "spray",
		image: "/banners/pest.jpg",
		from: "Rs 3,500",
		en: {
			name: "Pest control",
			short: "Cockroaches, termites, ants, bed bugs, and rodents.",
			headline: "A clean treatment. Not a fog that drives you out for a day.",
			lede: "Gel, bait, and targeted spray. Kitchens stay usable the same evening. Termite work is marked on a simple floor sketch.",
			jobs: [
				"Cockroach gel for kitchens",
				"Ant trails and nesting points",
				"Termite drill-and-inject",
				"Bed bug heat-and-spray plan",
				"Rodent bait stations, locked",
				"Mosquito breeding spots outside",
				"Pre-monsoon home package",
				"Annual society contract"
			]
		},
		ur: {
			name: "پیسٹ کنٹرول",
			short: "کاکروچ، دیمک، چیونٹیاں، کھٹمل اور چوہے۔",
			headline: "صاف ٹریٹمنٹ۔ ایسا دھواں نہیں کہ گھر چھوڑنا پڑے۔",
			lede: "جیل، بیٹ اور نشانہ والا سپرے۔ کچن اسی شام چل سکتا ہے۔ دیمک کا کام سادہ نقشے پر نشان زد۔",
			jobs: [
				"کچن کے لیے کاکروچ جیل",
				"چیونٹیوں کی لائن اور گھونسلہ",
				"دیمک ڈرل اور انجیکٹ",
				"کھٹمل کا پلان",
				"بند چوہہ بیٹ اسٹیشن",
				"باہر مچھر کی افزائش",
				"مون سون سے پہلے گھر پیکیج",
				"سالانہ سوسائٹی کنٹریکٹ"
			]
		}
	}
];
var banners = [
	{
		id: "same-day-spark",
		trade: "electrician",
		image: "/banners/wiring.jpg",
		price: "Rs 499 visit",
		en: {
			kicker: "Electrician banner",
			title: "Same-day spark call",
			body: "Tripping board, burning smell, or a room gone dark. Visit fee drops off the bill if we do the repair."
		},
		ur: {
			kicker: "الیکٹریشن بینر",
			title: "اسی دن کی بجلی کال",
			body: "بورڈ ٹرپ، جلے کی بو، یا کمرہ اندھیرا۔ مرمت کروائیں تو وزٹ فیس بل سے اتر جائے گی۔"
		}
	},
	{
		id: "wiring-audit",
		trade: "electrician",
		image: "/banners/hero.jpg",
		price: "Rs 2,500",
		en: {
			kicker: "Safety banner",
			title: "Whole-home wiring check",
			body: "We open the DB, test earth, and mark the points that run hot. You get a one-page list, not a scare story."
		},
		ur: {
			kicker: "سیفٹی بینر",
			title: "پورے گھر کی وائرنگ چیک",
			body: "ڈی بی کھولتے ہیں، ارتھ چیک کرتے ہیں، گرم پوائنٹ نشان زد۔ ایک صفحہ کی فہرست، ڈراوا نہیں۔"
		}
	},
	{
		id: "ac-summer",
		trade: "appliance",
		image: "/banners/ac.jpg",
		price: "From Rs 2,800",
		en: {
			kicker: "Appliance banner",
			title: "Split AC service before the heat sits",
			body: "Filter, drain, coil wash, and a gas check. If it needs a top-up, you see the gauge."
		},
		ur: {
			kicker: "اپلائنس بینر",
			title: "گرمی بیٹھنے سے پہلے اے سی سروس",
			body: "فلٹر، ڈرین، کوائل واش اور گیس چیک۔ ٹاپ اپ چاہیے تو گیج سامنے۔"
		}
	},
	{
		id: "washer-fridge",
		trade: "appliance",
		image: "/banners/appliance.jpg",
		price: "15% off the second",
		en: {
			kicker: "Combo banner",
			title: "Washer and fridge, one visit",
			body: "Book both machines on the same ticket. Labour on the second job is fifteen percent off."
		},
		ur: {
			kicker: "کومبو بینر",
			title: "واشر اور فریج، ایک وزٹ",
			body: "دونوں مشینیں ایک ٹکٹ پر۔ دوسری مشین کی مزدوری پندرہ فیصد کم۔"
		}
	},
	{
		id: "monsoon-drain",
		trade: "plumber",
		image: "/banners/monsoon.jpg",
		price: "From Rs 1,800",
		en: {
			kicker: "Plumber banner",
			title: "Monsoon drains, before the courtyard floods",
			body: "Roof outlets, courtyard traps, and the line that backs up when the lane fills. Booked ahead of the next spell."
		},
		ur: {
			kicker: "پلمبر بینر",
			title: "مون سون ڈرین، صحن بھرنے سے پہلے",
			body: "چھت کے آؤٹ لیٹ، صحن کے ٹریپ، اور وہ لائن جو گلی بھرے تو الٹی ہو۔ اگلے اسپیل سے پہلے بک کریں۔"
		}
	},
	{
		id: "leak-night",
		trade: "plumber",
		image: "/banners/plumber.jpg",
		price: "Rs 499 visit",
		en: {
			kicker: "Leak banner",
			title: "A leak does not wait for office hours",
			body: "Supply shut, then the joint. We carry common stops and mixer cartridges on the van."
		},
		ur: {
			kicker: "لیک بینر",
			title: "لیک دفتری وقت کا انتظار نہیں کرتی",
			body: "پہلے سپلائی بند، پھر جوڑ۔ وین پر عام سٹاپ اور مکسر کارتوس ہوتے ہیں۔"
		}
	},
	{
		id: "pest-package",
		trade: "pest",
		image: "/banners/pest.jpg",
		price: "From Rs 6,500",
		en: {
			kicker: "Pest banner",
			title: "Cockroach and termite, one home package",
			body: "Kitchen gel plus a termite walk of the ground floor. Two follow-ups inside forty days."
		},
		ur: {
			kicker: "پیسٹ بینر",
			title: "کاکروچ اور دیمک، ایک گھر پیکیج",
			body: "کچن جیل اور گراؤنڈ فلور کی دیمک چیک۔ چالیس دن میں دو فالو اپ۔"
		}
	},
	{
		id: "society",
		trade: "pest",
		image: "/banners/night.jpg",
		price: "Ask for the block rate",
		en: {
			kicker: "Building banner",
			title: "Society and apartment block rates",
			body: "One staircase, many flats. Electrical points, plumbing stacks, or a pest round — quoted per block, not per doorbell."
		},
		ur: {
			kicker: "بلڈنگ بینر",
			title: "سوسائٹی اور اپارٹمنٹ کے بلاک ریٹ",
			body: "ایک سیڑھی، کئی فلیٹ۔ بجلی، پلمبنگ یا پیسٹ — ریٹ فی بلاک، فی گھنٹی نہیں۔"
		}
	}
];
var ticker = [
	{
		en: "Same-day electrician inside the city",
		ur: "شہر میں اسی دن الیکٹریشن"
	},
	{
		en: "AC service from Rs 2,800",
		ur: "اے سی سروس 2,800 سے"
	},
	{
		en: "Monsoon drain booking is open",
		ur: "مون سون ڈرین کی بکنگ کھلی ہے"
	},
	{
		en: "Pest package with two follow-ups",
		ur: "پیسٹ پیکیج، دو فالو اپ"
	},
	{
		en: "Night line 021 111 442 700",
		ur: "رات کی لائن 021 111 442 700"
	},
	{
		en: "Visit fee adjusted if you proceed",
		ur: "کام کروائیں تو وزٹ فیس ایڈجسٹ"
	}
];
var reviews = [
	{
		en: {
			q: "The board had been tripping for a week. He found a wet joint in the kitchen point and wrote the price before opening the wall box.",
			n: "Ayesha K.",
			m: "DHA, Karachi · Electrician"
		},
		ur: {
			q: "بورڈ ایک ہفتے سے ٹرپ ہو رہا تھا۔ کچن پوائنٹ میں گیلا جوڑ ملا، اور دیوار کا ڈبہ کھولنے سے پہلے ریٹ لکھ دیا۔",
			n: "عائشہ کے۔",
			m: "ڈی ایچ اے، کراچی · الیکٹریشن"
		}
	},
	{
		en: {
			q: "Washer would fill and sit. New drain pump, fitted in the laundry, old pump left on the counter so I could see it.",
			n: "Bilal R.",
			m: "Gulberg, Lahore · Appliance"
		},
		ur: {
			q: "واشر پانی لے کر بیٹھ جاتی۔ نیا ڈرین پمپ وہیں لانڈری میں لگا، پرانا کاؤنٹر پر چھوڑا تاکہ میں دیکھ لوں۔",
			n: "بلال آر۔",
			m: "گلبرگ، لاہور · اپلائنس"
		}
	},
	{
		en: {
			q: "Termite skirting on the ground floor. They marked every drill on a sketch and came back on day twenty without me chasing.",
			n: "Sana M.",
			m: "Bahria, Rawalpindi · Pest"
		},
		ur: {
			q: "گراؤنڈ فلور کی سکرٹنگ میں دیمک۔ ہر ڈرل نقشے پر نشان، اور بیسویں دن خود واپس آئے۔",
			n: "ثنا ایم۔",
			m: "بحریہ، راولپنڈی · پیسٹ"
		}
	}
];
var faqs = [
	{
		en: {
			q: "Do you take the payment on the website?",
			a: "No. This page only sends the request. The desk calls, agrees a window, and the tech collects after you accept the written quote."
		},
		ur: {
			q: "کیا ویب سائٹ پر پیسے کٹتے ہیں؟",
			a: "نہیں۔ یہ صفحہ صرف درخواست بھیجتا ہے۔ ڈیسک کال کرتی ہے، وقت طے ہوتا ہے، اور کوٹ قبول کرنے کے بعد تکنیشن لیتا ہے۔"
		}
	},
	{
		en: {
			q: "Is the visit fee extra if I go ahead?",
			a: "The Rs 499 visit is waived against labour when you approve the job. If you decline, you pay the visit and we leave."
		},
		ur: {
			q: "کام کروانے پر وزٹ فیس الگ ہے؟",
			a: "499 روپے کی وزٹ فیس مزدوری میں مائنس ہو جاتی ہے جب آپ کام منظور کریں۔ انکار ہو تو صرف وزٹ، اور ہم چلے جاتے ہیں۔"
		}
	},
	{
		en: {
			q: "Which areas inside a city?",
			a: "Main residential sectors, DHA, Bahria, Gulberg, Clifton, F-sectors, and the ring inside the motorway. Tell us the area on the call if you are on the edge."
		},
		ur: {
			q: "شہر کے اندر کون سے علاقے؟",
			a: "بڑے رہائشی سیکٹر، ڈی ایچ اے، بحریہ، گلبرگ، کلفٹن، ایف سیکٹر، اور موٹروے کے اندر کا حلقہ۔ کنارے پر ہوں تو کال پر علاقہ بتائیں۔"
		}
	},
	{
		en: {
			q: "Are parts genuine?",
			a: "We fit the brand part or a named equivalent, and we say which before it goes in. No loose ‘company piece’ story."
		},
		ur: {
			q: "پرزے اصلی ہوتے ہیں؟",
			a: "برانڈ پرزہ یا نام والا متبادل لگتا ہے، اور لگنے سے پہلے بتا دیا جاتا ہے۔ ‘کمپنی والا’ کہانی نہیں۔"
		}
	},
	{
		en: {
			q: "Can one visit cover two trades?",
			a: "Often yes — a geyser is both a plumber and an electrician. Book the louder fault. If a second trade is needed, we say so before sending another person."
		},
		ur: {
			q: "ایک وزٹ میں دو سروسز؟",
			a: "اکثر ہاں — گیزر پلمبر بھی ہے اور الیکٹریشن بھی۔ بڑی خرابی بک کریں۔ دوسری سروس چاہیے تو دوسرے آدمی بھیجنے سے پہلے بتاتے ہیں۔"
		}
	},
	{
		en: {
			q: "What about pets and children during pest control?",
			a: "Gel work needs no one to leave. Spray rooms are aired and we tell you how long to stay out — usually two hours, not the whole day."
		},
		ur: {
			q: "پیسٹ کنٹرول میں بچے اور پالتو؟",
			a: "جیل کے لیے گھر خالی کرنے کی ضرورت نہیں۔ سپرے والے کمرے ہوا دار ہوتے ہیں اور بتایا جاتا ہے کتنی دیر باہر رہنا ہے — عموماً دو گھنٹے، پورا دن نہیں۔"
		}
	}
];
function tradeBySlug(slug) {
	return trades.find((t) => t.slug === slug);
}
var LanguageContext = (0, import_react.createContext)(null);
function LanguageProvider({ children }) {
	const [lang, setLangState] = (0, import_react.useState)("en");
	(0, import_react.useEffect)(() => {
		const saved = localStorage.getItem("gharline-lang");
		if (saved === "ur" || saved === "en") setLangState(saved);
	}, []);
	(0, import_react.useEffect)(() => {
		document.documentElement.lang = lang === "ur" ? "ur" : "en";
		document.documentElement.dir = lang === "ur" ? "rtl" : "ltr";
	}, [lang]);
	const setLang = (next) => {
		setLangState(next);
		localStorage.setItem("gharline-lang", next);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageContext.Provider, {
		value: {
			lang,
			setLang,
			copy: ui[lang]
		},
		children
	});
}
function useI18n() {
	const value = (0, import_react.useContext)(LanguageContext);
	if (!value) throw new Error("useI18n must be used under LanguageProvider");
	return value;
}
//#endregion
export { banners as a, reviews as c, tradeBySlug as d, trades as f, PHONE_TEL as i, slots as l, LanguageProvider as n, cities as o, useI18n as p, PHONE_DISPLAY as r, faqs as s, DOMAIN as t, ticker as u };
