import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, b as Link, p as useRouterState, q as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as trades, i as PHONE_TEL, p as useI18n, r as PHONE_DISPLAY, t as DOMAIN, u as ticker } from "./i18n-Bpg8-YJB.mjs";
import { a as SprayCan, c as Droplets, d as ArrowRight, n as X, o as Phone, r as WashingMachine, s as Menu, t as Zap } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/site-chrome-BsLshem2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function tradeIcon(icon, className) {
	if (icon === "zap") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, {
		className,
		"aria-hidden": true
	});
	if (icon === "washer") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WashingMachine, {
		className,
		"aria-hidden": true
	});
	if (icon === "drops") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Droplets, {
		className,
		"aria-hidden": true
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SprayCan, {
		className,
		"aria-hidden": true
	});
}
function Mark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className,
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M5 15.5 16 6l11 9.5",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2.2",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M9 15.5V26h14V15.5",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2.2",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 22h16",
				stroke: "var(--color-copper)",
				strokeWidth: "2.2"
			})
		]
	});
}
function Page({ children }) {
	const { lang } = useI18n();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		dir: lang === "ur" ? "rtl" : "ltr",
		className: "min-h-screen bg-bg text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ticker, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			children,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileDock, {})
		]
	});
}
function Ticker() {
	const { lang } = useI18n();
	const line = ticker.map((item) => item[lang]);
	const row = [...line, ...line];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-hidden bg-ink text-paper",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "ticker-track flex w-max",
			children: [0, 1].map((copy) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "flex shrink-0 items-center",
				children: row.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "px-5 py-2 text-sm whitespace-nowrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "me-5 inline-block size-1.5 translate-y-[-1px] rounded-full bg-copper" }), item]
				}, `${copy}-${i}`))
			}, copy))
		})
	});
}
function SiteHeader() {
	const { lang, setLang, copy } = useI18n();
	const path = useRouterState({ select: (s) => s.location.pathname });
	const [open, setOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setOpen(false);
	}, [path, lang]);
	const links = [
		{
			to: "/",
			label: copy.home,
			active: path === "/"
		},
		{
			to: "/services",
			label: copy.services,
			active: path.startsWith("/services")
		},
		{
			to: "/offers",
			label: copy.offers,
			active: path.startsWith("/offers")
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-40 border-b border-line bg-paper/95 backdrop-blur",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-6xl items-center gap-3 px-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-9 text-ink" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "leading-tight",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-display text-xl text-ink",
							children: "GharLine"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs text-muted",
							children: DOMAIN
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "ms-6 hidden items-center gap-1 lg:flex",
					children: links.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: item.to,
						className: `rounded-full px-3 py-2 text-sm font-medium ${item.active ? "bg-bg text-ink" : "text-muted hover:text-ink"}`,
						children: item.label
					}, item.to))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ms-auto flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setLang(lang === "en" ? "ur" : "en"),
							className: "inline-flex h-11 items-center rounded-full border border-line px-3 text-sm font-semibold text-ink",
							children: lang === "en" ? "اردو" : "EN"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: `tel:${PHONE_TEL}`,
							className: "hidden h-11 items-center gap-2 rounded-full border border-line px-3 text-sm font-semibold text-ink sm:inline-flex",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
								className: "size-4",
								"aria-hidden": true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								dir: "ltr",
								children: PHONE_DISPLAY
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/book",
							search: { service: "" },
							className: "inline-flex h-11 items-center gap-2 rounded-full bg-copper px-4 text-sm font-semibold text-paper hover:bg-copper-deep",
							children: copy.book
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex size-11 items-center justify-center rounded-full border border-line lg:hidden",
							"aria-expanded": open,
							"aria-label": open ? copy.close : copy.menu,
							onClick: () => setOpen((v) => !v),
							children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
						})
					]
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "border-t border-line bg-paper px-4 py-3 lg:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-col gap-1",
				children: [links.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: item.to,
					className: "flex min-h-12 items-center rounded-2xl px-3 text-lg",
					children: item.label
				}, item.to)), trades.map((trade) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/services/$slug",
					params: { slug: trade.slug },
					className: "flex min-h-12 items-center gap-3 rounded-2xl px-3 text-lg",
					children: [tradeIcon(trade.icon, "size-5 text-copper"), trade[lang].name]
				}, trade.slug))]
			})
		}) : null]
	});
}
function MobileDock() {
	const { copy } = useI18n();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-x-0 bottom-0 z-40 flex gap-2 border-t border-line bg-paper p-3 lg:hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
			href: `tel:${PHONE_TEL}`,
			className: "inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-full border border-line text-sm font-semibold",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
				className: "size-4",
				"aria-hidden": true
			}), copy.call]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/book",
			search: { service: "" },
			className: "inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-full bg-copper text-sm font-semibold text-paper",
			children: [copy.book, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
				className: "size-4 rtl:rotate-180",
				"aria-hidden": true
			})]
		})]
	});
}
function SiteFooter() {
	const { lang, copy } = useI18n();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t border-line bg-ink text-paper",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-10 px-4 py-14 sm:grid-cols-2 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl",
						children: "GharLine"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-copper",
						dir: "ltr",
						children: DOMAIN
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-paper/80",
						children: copy.heroLede
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-copper",
					children: copy.services
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: trades.map((trade) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/services/$slug",
						params: { slug: trade.slug },
						className: "text-sm hover:underline",
						children: trade[lang].name
					}) }, trade.slug))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-copper",
					children: copy.coverageLabel
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-6 text-paper/80",
					children: lang === "en" ? "Karachi, Lahore, Islamabad, Rawalpindi, Faisalabad, Multan, Peshawar, Hyderabad." : "کراچی، لاہور، اسلام آباد، راولپنڈی، فیصل آباد، ملتان، پشاور، حیدرآباد۔"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-copper",
						children: copy.domainLine
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: `tel:${PHONE_TEL}`,
						className: "mt-3 block text-lg font-semibold",
						dir: "ltr",
						children: PHONE_DISPLAY
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-paper/80",
						dir: "ltr",
						children: "desk@gharline.com"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-paper/70",
						children: copy.confirmNote
					})
				] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-paper/15",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mx-auto max-w-6xl px-4 py-4 text-xs text-paper/60",
				children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" GharLine · ",
					DOMAIN
				]
			})
		})]
	});
}
function Cta({ to, children, tone = "copper", search }) {
	const className = tone === "copper" ? "inline-flex h-12 items-center justify-center gap-2 rounded-full bg-copper px-5 text-sm font-semibold text-paper hover:bg-copper-deep" : tone === "paper" ? "inline-flex h-12 items-center justify-center gap-2 rounded-full bg-paper px-5 text-sm font-semibold text-ink" : "inline-flex h-12 items-center justify-center gap-2 rounded-full border border-paper/30 px-5 text-sm font-semibold text-paper";
	if (to === "/book") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/book",
		search: search ?? { service: "" },
		className,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
			className: "size-4 rtl:rotate-180",
			"aria-hidden": true
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
			className: "size-4 rtl:rotate-180",
			"aria-hidden": true
		})]
	});
}
//#endregion
export { Page as n, tradeIcon as r, Cta as t };
