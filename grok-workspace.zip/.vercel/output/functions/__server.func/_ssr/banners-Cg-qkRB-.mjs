import { b as Link, q as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as trades, p as useI18n } from "./i18n-Bpg8-YJB.mjs";
import { d as ArrowRight, u as Check } from "../_libs/lucide-react.mjs";
import { r as tradeIcon, t as Cta } from "./site-chrome-BsLshem2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/banners-Cg-qkRB-.js
var import_jsx_runtime = require_jsx_runtime();
function Hero() {
	const { copy, lang } = useI18n();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "bg-ink text-paper lg:grid lg:min-h-hero lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative min-h-72 lg:min-h-full",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/banners/hero.jpg",
				alt: lang === "en" ? "Electrician at a home breaker panel" : "گھر کے بریکر بورڈ پر الیکٹریشن",
				width: 1792,
				height: 1008,
				className: "absolute inset-0 h-full w-full object-cover"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col justify-center px-5 py-10 sm:px-10 lg:px-12 lg:py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-paper",
					children: copy.heroKicker
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-4 block h-1 w-12 rounded-full bg-copper" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 max-w-xl font-display text-4xl text-paper sm:text-5xl lg:text-6xl",
					children: copy.heroTitle
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-xl text-lg text-paper/85",
					children: copy.heroLede
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cta, {
						to: "/book",
						children: copy.book
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cta, {
						to: "/offers",
						tone: "ghost",
						children: copy.allBanners
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 grid grid-cols-2 gap-2",
					children: trades.map((trade) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/services/$slug",
						params: { slug: trade.slug },
						className: "flex min-h-14 items-center gap-2 rounded-2xl bg-paper/10 px-3 py-2 text-sm font-semibold hover:bg-paper/15",
						children: [tradeIcon(trade.icon, "size-4 shrink-0 text-paper"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: trade[lang].name })]
					}, trade.slug))
				})
			]
		})]
	});
}
function StatBar() {
	const { copy } = useI18n();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-b border-line bg-paper",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
			className: "mx-auto grid max-w-6xl grid-cols-2 md:grid-cols-4",
			children: copy.stats.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-line px-5 py-5 md:border-s md:first:border-s-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "font-display text-3xl tabular-nums text-ink",
					children: stat.n
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: "mt-1 text-sm text-muted",
					children: stat.l
				})]
			}, stat.l))
		})
	});
}
function TradeCard({ trade }) {
	const { lang, copy } = useI18n();
	const text = trade[lang];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/services/$slug",
		params: { slug: trade.slug },
		className: "group flex flex-col overflow-hidden rounded-card border border-line bg-ink text-paper",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative h-52 overflow-hidden sm:h-64",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: trade.image,
				alt: "",
				className: "h-full w-full object-cover motion-safe:transition motion-safe:duration-700 motion-safe:group-hover:scale-105"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-sm font-semibold",
					children: [tradeIcon(trade.icon, "size-4"), text.name]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-3 font-display text-2xl",
					children: text.headline
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 flex-1 text-sm text-paper/80",
					children: text.short
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-sm font-semibold tabular-nums",
					children: [
						copy.from,
						" ",
						trade.from
					]
				})
			]
		})]
	});
}
function BillBanner({ banner, flip = false }) {
	const { lang, copy } = useI18n();
	const text = banner[lang];
	const service = banner.trade === "any" ? "" : banner.trade;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "grid overflow-hidden rounded-card border border-line bg-paper md:grid-cols-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `relative min-h-banner md:col-span-2 ${flip ? "md:order-2" : ""}`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: banner.image,
				alt: "",
				className: "absolute inset-0 h-full w-full object-cover"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col justify-center gap-3 p-6 md:col-span-3 md:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-copper",
					children: text.kicker
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-3xl text-ink sm:text-4xl",
					children: text.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-xl text-muted",
					children: text.body
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl tabular-nums text-ink",
					children: banner.price
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cta, {
					to: "/book",
					search: { service },
					children: copy.book
				}) })
			]
		})]
	});
}
function BannerList({ items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-col gap-5",
		children: items.map((banner, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BillBanner, {
			banner,
			flip: index % 2 === 1
		}, banner.id))
	});
}
function EmergencyBand() {
	const { copy } = useI18n();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-bg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl overflow-hidden rounded-card border border-line bg-ink text-paper lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative min-h-72",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/banners/night.jpg",
					alt: "",
					className: "absolute inset-0 h-full w-full object-cover"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col justify-center p-6 sm:p-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold",
						children: copy.emergencyKicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-4 block h-1 w-12 rounded-full bg-copper" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 font-display text-3xl sm:text-4xl",
						children: copy.emergencyTitle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-paper/80",
						children: copy.emergencyBody
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cta, {
							to: "/book",
							search: { service: "electrician" },
							children: copy.book
						})
					})
				]
			})]
		})
	});
}
function ClosingBand() {
	const { copy } = useI18n();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-bg pb-24 lg:pb-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl items-center gap-6 overflow-hidden rounded-card bg-copper px-6 py-10 text-paper sm:px-10 lg:grid-cols-[1.4fr_auto]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl sm:text-5xl",
				children: copy.closingTitle
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-xl text-paper",
				children: copy.closingBody
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cta, {
				to: "/book",
				tone: "paper",
				children: copy.book
			})]
		})
	});
}
function JobList({ jobs }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "grid gap-3 sm:grid-cols-2",
		children: jobs.map((job) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-start gap-3 rounded-2xl border border-line bg-paper px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
				className: "mt-0.5 size-4 shrink-0 text-copper",
				"aria-hidden": true
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: job })]
		}, job))
	});
}
function TradeStrip({ except }) {
	const { lang, copy } = useI18n();
	const items = trades.filter((trade) => trade.slug !== except);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "font-display text-3xl",
		children: copy.otherTrades
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-4 grid gap-3 sm:grid-cols-3",
		children: items.map((trade) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/services/$slug",
			params: { slug: trade.slug },
			className: "overflow-hidden rounded-card border border-line bg-paper",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: trade.image,
				alt: "",
				className: "h-36 w-full object-cover"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex items-center justify-between px-4 py-3 text-sm font-semibold",
				children: [trade[lang].name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
					className: "size-4 rtl:rotate-180",
					"aria-hidden": true
				})]
			})]
		}, trade.slug))
	})] });
}
//#endregion
export { JobList as a, TradeStrip as c, Hero as i, ClosingBand as n, StatBar as o, EmergencyBand as r, TradeCard as s, BannerList as t };
