import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, q as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as trades, l as slots, o as cities, p as useI18n } from "./i18n-Bpg8-YJB.mjs";
import { n as Page } from "./site-chrome-BsLshem2.mjs";
import { r as Route$3 } from "./router-CM_JRMzg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/book-QEWggWTW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STORAGE_KEY = "gharline-requests";
function readRows() {
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed.slice(0, 6) : [];
	} catch {
		return [];
	}
}
function BookingForm({ initialService = "" }) {
	const { lang, copy } = useI18n();
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [city, setCity] = (0, import_react.useState)("");
	const [service, setService] = (0, import_react.useState)(initialService);
	const [when, setWhen] = (0, import_react.useState)(slots[0].en);
	const [note, setNote] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [ticket, setTicket] = (0, import_react.useState)("");
	const [rows, setRows] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		setRows(readRows());
	}, []);
	(0, import_react.useEffect)(() => {
		if (initialService) setService(initialService);
	}, [initialService]);
	const field = "h-12 w-full rounded-2xl border border-line bg-paper px-4 text-ink outline-none";
	function submit(event) {
		event.preventDefault();
		if (name.trim().length < 2) return setError(copy.needName);
		if (!/^(?:\+?92|0)?3\d{9}$/.test(phone.replace(/[\s-]/g, ""))) return setError(copy.needPhone);
		if (!city) return setError(copy.needCity);
		if (!trades.some((trade) => trade.slug === service)) return setError(copy.needService);
		if (note.trim().length < 8) return setError(copy.needNote);
		const next = {
			ticket: `GL-${Math.floor(1e4 + Math.random() * 89999)}`,
			name: name.trim(),
			phone: phone.trim(),
			city,
			service,
			when,
			note: note.trim(),
			at: (/* @__PURE__ */ new Date()).toISOString()
		};
		const saved = [next, ...readRows()].slice(0, 6);
		localStorage.setItem(STORAGE_KEY, JSON.stringify(saved));
		setRows(saved);
		setTicket(next.ticket);
		setError("");
	}
	if (ticket) {
		const trade = trades.find((item) => item.slug === service);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "status",
			className: "rounded-card border border-line bg-paper p-6 sm:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-copper",
					children: copy.ticket
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-display text-4xl",
					children: copy.successTitle
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 font-display text-3xl tabular-nums",
					dir: "ltr",
					children: ticket
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-muted",
					children: copy.confirmNote
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-6 grid gap-3 text-sm sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: copy.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-semibold",
							children: name
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: copy.phone
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-semibold",
							dir: "ltr",
							children: phone
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: copy.city
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-semibold",
							children: cities.find((item) => item.en === city)?.[lang] ?? city
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: copy.service
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-semibold",
							children: trade ? trade[lang].name : service
						})] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-sm text-muted",
					children: copy.onDevice
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-4 inline-flex h-11 items-center rounded-full border border-line px-4 text-sm font-semibold",
					onClick: () => {
						setTicket("");
						setNote("");
					},
					children: copy.book
				})
			]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-[1.4fr_0.8fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			className: "rounded-card border border-line bg-paper p-5 sm:p-8",
			noValidate: true,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-semibold",
							children: [copy.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: `${field} mt-2`,
								value: name,
								onChange: (e) => setName(e.target.value),
								autoComplete: "name"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-semibold",
							children: [copy.phone, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: `${field} mt-2`,
								value: phone,
								onChange: (e) => setPhone(e.target.value),
								autoComplete: "tel",
								inputMode: "tel",
								dir: "ltr",
								placeholder: "03xx xxx xxxx"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-semibold",
							children: [copy.city, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: `${field} mt-2`,
								value: city,
								onChange: (e) => setCity(e.target.value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: copy.choose
								}), cities.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: item.en,
									children: item[lang]
								}, item.en))]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-semibold",
							children: [copy.service, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: `${field} mt-2`,
								value: service,
								onChange: (e) => setService(e.target.value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: copy.choose
								}), trades.map((trade) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: trade.slug,
									children: trade[lang].name
								}, trade.slug))]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-semibold sm:col-span-2",
							children: [copy.when, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: `${field} mt-2`,
								value: when,
								onChange: (e) => setWhen(e.target.value),
								children: slots.map((slot) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: slot.en,
									children: slot[lang]
								}, slot.en))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-semibold sm:col-span-2",
							children: [copy.note, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								className: "mt-2 min-h-32 w-full rounded-2xl border border-line bg-paper px-4 py-3 text-ink outline-none",
								value: note,
								onChange: (e) => setNote(e.target.value)
							})]
						})
					]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "alert",
					className: "mt-4 text-sm font-semibold text-copper",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-muted",
					children: copy.visitNote
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "mt-5 inline-flex h-12 items-center rounded-full bg-copper px-6 text-sm font-semibold text-paper hover:bg-copper-deep",
					children: copy.submit
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "rounded-card border border-line bg-ink p-5 text-paper sm:p-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: copy.recent
			}), rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-paper/75",
				children: copy.onDevice
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 space-y-3",
				children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-2xl bg-paper/10 px-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold tabular-nums",
						dir: "ltr",
						children: row.ticket
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-paper/80",
						children: [
							trades.find((trade) => trade.slug === row.service)?.[lang].name ?? row.service,
							" · ",
							cities.find((item) => item.en === row.city)?.[lang] ?? row.city
						]
					})]
				}, row.ticket))
			})]
		})]
	});
}
function BookPage() {
	const { service } = Route$3.useSearch();
	const { copy } = useI18n();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-12 pb-28",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid items-end gap-6 lg:grid-cols-[1.1fr_0.9fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-copper",
					children: "gharline.com"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-display text-4xl sm:text-6xl",
					children: copy.book
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-xl text-lg text-muted",
					children: copy.closingBody
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/banners/ac.jpg",
				alt: "",
				className: "h-48 w-full rounded-card object-cover lg:h-56"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingForm, { initialService: service })
		})]
	}) });
}
//#endregion
export { BookPage as component };
