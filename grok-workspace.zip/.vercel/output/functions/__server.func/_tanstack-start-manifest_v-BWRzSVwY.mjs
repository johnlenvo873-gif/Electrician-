//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BWRzSVwY.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/$",
			"/book",
			"/offers",
			"/services/$slug",
			"/services/"
		],
		preloads: [
			"/assets/index-BPRyJguY.js",
			"/assets/i18n-DDAKenN3.js",
			"/assets/preload-helper-CAjgBWmM.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BPRyJguY.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-xmpqIgSR.js",
			"/assets/site-chrome-8gNLTjy7.js",
			"/assets/banners-CyQvMJ-N.js"
		]
	},
	"/$": {
		filePath: "/workspace/src/routes/$.tsx",
		children: void 0,
		preloads: ["/assets/_-BM3IWKs9.js", "/assets/site-chrome-8gNLTjy7.js"]
	},
	"/book": {
		filePath: "/workspace/src/routes/book.tsx",
		children: void 0,
		preloads: ["/assets/book-4H53PAnQ.js", "/assets/site-chrome-8gNLTjy7.js"]
	},
	"/offers": {
		filePath: "/workspace/src/routes/offers.tsx",
		children: void 0,
		preloads: [
			"/assets/offers-CEWBJCDj.js",
			"/assets/site-chrome-8gNLTjy7.js",
			"/assets/banners-CyQvMJ-N.js"
		]
	},
	"/services/$slug": {
		filePath: "/workspace/src/routes/services/$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-BEoumUvP.js",
			"/assets/site-chrome-8gNLTjy7.js",
			"/assets/banners-CyQvMJ-N.js"
		]
	},
	"/services/": {
		filePath: "/workspace/src/routes/services/index.tsx",
		children: void 0,
		preloads: [
			"/assets/services-CBe5GKlo.js",
			"/assets/site-chrome-8gNLTjy7.js",
			"/assets/banners-CyQvMJ-N.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
