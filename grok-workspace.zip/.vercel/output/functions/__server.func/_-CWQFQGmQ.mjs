import { b as Link, q as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { p as useI18n } from "./_ssr/i18n-Bpg8-YJB.mjs";
import { n as Page } from "./_ssr/site-chrome-BsLshem2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_-CWQFQGmQ.js
var import_jsx_runtime = require_jsx_runtime();
function Missing() {
	const { copy } = useI18n();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-xl px-4 py-24 pb-32 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: copy.notFoundTitle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: copy.notFoundBody
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "mt-6 inline-flex h-12 items-center rounded-full bg-copper px-5 font-semibold text-paper",
				children: copy.backHome
			})
		]
	}) });
}
//#endregion
export { Missing as component };
