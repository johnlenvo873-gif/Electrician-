export const DOMAIN = "gharline.com";
export const PHONE_DISPLAY = "(800) 442-7000";
export const PHONE_TEL = "+18004427000";

export const ui = {
  book: "Book a visit",
  call: "Call the desk",
  home: "Home",
  services: "Services",
  offers: "Offers",
  menu: "Menu",
  close: "Close",
  from: "From",
  seeTrade: "Open this trade",
  bookThis: "Book this trade",
  included: "What we actually fix",
  howTitle: "How a visit works",
  howLede: "No surprise invoice. You hear the number before a tool comes out of the bag.",
  citiesTitle: "Eight metros on the line",
  citiesLede:
    "Crews roll the same day inside these metros. Outside the beltway, we book the next morning window.",
  reviewsTitle: "From houses we have already been in",
  faqTitle: "Before you call",
  allBanners: "Every live offer",
  bannerLede: "Seasonal work, night call-outs, and package rates. Tap one to book that job.",
  notFoundTitle: "This page is not on the line",
  notFoundBody: "That address is wrong, or that trade is not listed yet.",
  backHome: "Back to GharLine",
  name: "Your name",
  phone: "Mobile number",
  city: "Metro",
  service: "Trade",
  when: "When should we come",
  note: "What's wrong",
  submit: "Send the request",
  successTitle: "Request is on the desk",
  ticket: "Ticket",
  confirmNote:
    "No payment on this page. The desk calls this number to lock the window and read the quote.",
  onDevice: "Saved on this device only.",
  recent: "Requests from this device",
  needName: "Enter your name.",
  needPhone: "Enter a 10-digit U.S. phone number.",
  needCity: "Pick a metro.",
  needService: "Pick a trade.",
  needNote: "Tell us the problem in a sentence.",
  visitNote:
    "Trip fee $49, credited to the bill if you go ahead. Parts stay on the written quote.",
  choose: "Choose",
  priceNote: "Labor starts at this figure. Parts are extra and shown before we install them.",
  related: "Offers for this trade",
  otherTrades: "The other three trades",
  promiseTitle: "The line we keep",
  coverageLabel: "Coverage",
  domainLine: "The home desk",
  heroKicker: "Electrician · Appliances · Plumber · Pest control",
  heroTitle: "The only line your house needs.",
  heroLede:
    "One desk for power, machines, pipes, and pests. Licensed techs in eight U.S. metros, a written quote, and 30-day coverage on the work.",
  servicesTitle: "Four trades. Plenty of offers.",
  servicesLede: "Pick the problem. Each card opens the jobs, the starting rate, and a booking for that crew.",
  emergencyKicker: "Night desk",
  emergencyTitle: "Lights out, a burst pipe, or something moving in the kitchen.",
  emergencyBody:
    "The night line stays open. A tech is dispatched with the same quote rule — you approve, then we open the toolbox.",
  closingTitle: "Put the house back on the line.",
  closingBody: "Tell us the metro and the problem. We call back with a window, not a chatbot.",
  steps: [
    { t: "Call or book", d: "Name the trade and what stopped working. A person answers." },
    { t: "Quote at the door", d: "The tech writes the labor and parts. You can say no." },
    { t: "Fix, then cover", d: "Workmanship is covered for 30 days. We come back if it fails." },
  ],
  promises: [
    { t: "Quote first", d: "Nothing starts until you nod at the number." },
    { t: "Same-day metros", d: "Inside New York, Los Angeles, Chicago, and the other five when the board is open." },
    { t: "30-day coverage", d: "If our work fails, the return visit is on us." },
    { t: "Parts you can see", d: "The old part comes out. The new part is in your hand before it goes in." },
  ],
  stats: [
    { n: "8", l: "Metros" },
    { n: "4", l: "Trades" },
    { n: "30", l: "Day coverage" },
    { n: "24/7", l: "Night line" },
  ],
} as const;

export const cities = [
  "New York",
  "Los Angeles",
  "Chicago",
  "Houston",
  "Phoenix",
  "Philadelphia",
  "Dallas",
  "Miami",
];

export const slots = [
  "Today — same-day window",
  "Tomorrow morning",
  "Tomorrow evening",
  "This week — call me to pick",
];

export type TradeSlug = "electrician" | "appliance" | "plumber" | "pest";

export type Trade = {
  slug: TradeSlug;
  icon: "zap" | "washer" | "drops" | "spray";
  image: string;
  from: string;
  name: string;
  short: string;
  headline: string;
  lede: string;
  jobs: string[];
};

export const trades: Trade[] = [
  {
    slug: "electrician",
    icon: "zap",
    image: "/banners/hero.jpg",
    from: "$89",
    name: "Electrician",
    short: "Tripping breakers, dead outlets, fans, water heaters, and EV chargers.",
    headline: "The breaker keeps tripping. The fan hums and sits.",
    lede: "House wiring, panels, outlets, and the machines that run on them. We do not guess at a live short.",
    jobs: [
      "Breaker and panel faults",
      "New switch, outlet, or GFCI",
      "Ceiling fan and light install",
      "Short-circuit tracing",
      "EV charger circuit",
      "Water heater element and thermostat",
      "Doorbell, exhaust fan, and recessed lights",
      "Whole-home electrical safety check",
    ],
  },
  {
    slug: "appliance",
    icon: "washer",
    image: "/banners/appliance.jpg",
    from: "$79",
    name: "Appliance repair",
    short: "Washers, fridges, ranges, and the AC that quit last night.",
    headline: "The machine has a nameplate. We bring the parts for it.",
    lede: "Major appliances stay in the house. We haul one away only if the motor is finished and you agree.",
    jobs: [
      "Washer not spinning or draining",
      "Fridge warm, icing up, or noisy",
      "Microwave and range faults",
      "Dishwasher leaks and error codes",
      "Central AC and mini-split service",
      "Dryer belts and heating elements",
      "Jammed garbage disposal",
      "Dedicated circuit for a heavy appliance",
    ],
  },
  {
    slug: "plumber",
    icon: "drops",
    image: "/banners/plumber.jpg",
    from: "$89",
    name: "Plumber",
    short: "Leaks, clogged lines, water heaters, and faucets.",
    headline: "Water where it should not be. None where it should.",
    lede: "Supply, drain, and the heater that feeds the house. We open the trap before we talk about opening a wall.",
    jobs: [
      "Kitchen and bath leaks",
      "Clogged drain and toilet",
      "Toilet, flapper, and shower valve",
      "Faucet and shutoff valve",
      "Water heater supply and relief valve",
      "Sump pump",
      "Garbage disposal hookup",
      "Storm and yard drain backup",
    ],
  },
  {
    slug: "pest",
    icon: "spray",
    image: "/banners/pest.jpg",
    from: "$149",
    name: "Pest control",
    short: "Roaches, termites, ants, bed bugs, and rodents.",
    headline: "A clean treatment. Not a fog that drives you out for the day.",
    lede: "Gel, bait, and targeted spray. Kitchens stay usable the same evening. Termite work is marked on a simple floor sketch.",
    jobs: [
      "Roach gel for kitchens",
      "Ant trails and nesting points",
      "Termite inspection and treatment",
      "Bed bug plan",
      "Locked rodent bait stations",
      "Mosquito breeding spots outside",
      "Pre-summer home package",
      "HOA and apartment contract",
    ],
  },
];

export type Banner = {
  id: string;
  trade: TradeSlug | "any";
  image: string;
  price: string;
  kicker: string;
  title: string;
  body: string;
};

export const banners: Banner[] = [
  {
    id: "same-day-spark",
    trade: "electrician",
    image: "/banners/wiring.jpg",
    price: "$49 trip",
    kicker: "Electrician offer",
    title: "Same-day electrical call",
    body: "A tripping panel, a burning smell, or a room gone dark. The trip fee comes off the bill if we do the repair.",
  },
  {
    id: "wiring-audit",
    trade: "electrician",
    image: "/banners/hero.jpg",
    price: "$149",
    kicker: "Safety offer",
    title: "Whole-home electrical check",
    body: "We open the panel, test the ground, and mark the circuits that run hot. You get a one-page list, not a scare story.",
  },
  {
    id: "ac-summer",
    trade: "appliance",
    image: "/banners/ac.jpg",
    price: "From $129",
    kicker: "Appliance offer",
    title: "AC tune-up before the heat sticks",
    body: "Filter, drain, coil wash, and a refrigerant check. If it needs a top-off, you see the gauge.",
  },
  {
    id: "washer-fridge",
    trade: "appliance",
    image: "/banners/appliance.jpg",
    price: "15% off the second",
    kicker: "Combo offer",
    title: "Washer and fridge, one visit",
    body: "Book both machines on the same ticket. Labor on the second job is fifteen percent off.",
  },
  {
    id: "storm-drain",
    trade: "plumber",
    image: "/banners/monsoon.jpg",
    price: "From $149",
    kicker: "Plumber offer",
    title: "Storm drains, before the yard floods",
    body: "Downspouts, yard drains, and the line that backs up when the street fills. Book ahead of the next storm.",
  },
  {
    id: "leak-night",
    trade: "plumber",
    image: "/banners/plumber.jpg",
    price: "$49 trip",
    kicker: "Leak offer",
    title: "A leak does not wait for office hours",
    body: "Supply shut off, then the joint. The van carries common stops and faucet cartridges.",
  },
  {
    id: "pest-package",
    trade: "pest",
    image: "/banners/pest.jpg",
    price: "From $349",
    kicker: "Pest offer",
    title: "Roach and termite, one home package",
    body: "Kitchen gel plus a termite walk of the ground floor. Two follow-ups inside forty days.",
  },
  {
    id: "building",
    trade: "pest",
    image: "/banners/night.jpg",
    price: "Ask for the building rate",
    kicker: "Building offer",
    title: "HOA and apartment building rates",
    body: "One stairwell, many units. Electrical, plumbing stacks, or a pest round — quoted per building, not per doorbell.",
  },
];

export const ticker = [
  "Same-day electrician inside the metro",
  "AC tune-up from $129",
  "Storm-drain booking is open",
  "Pest package with two follow-ups",
  "Night line (800) 442-7000",
  "Trip fee credited if you go ahead",
];

export const reviews = [
  {
    q: "The panel had been tripping for a week. He found a damp splice on the kitchen circuit and wrote the price before he opened the box.",
    n: "Maya L.",
    m: "Park Slope, Brooklyn · Electrician",
  },
  {
    q: "The washer would fill and sit. New drain pump, fitted in the laundry room, old pump left on the counter so I could see it.",
    n: "Andre P.",
    m: "Houston Heights · Appliance",
  },
  {
    q: "Termites in the ground-floor baseboard. They marked every drill on a sketch and came back on day twenty without me chasing them.",
    n: "Priya S.",
    m: "Scottsdale · Pest control",
  },
];

export const faqs = [
  {
    q: "Do you take payment on the website?",
    a: "No. This page only sends the request. The desk calls, agrees on a window, and the tech collects after you accept the written quote.",
  },
  {
    q: "Is the trip fee extra if I go ahead?",
    a: "The $49 trip fee is credited toward labor when you approve the job. If you decline, you pay the trip and we leave.",
  },
  {
    q: "Which neighborhoods do you cover?",
    a: "City limits and close-in suburbs in the eight metros. If you are near the edge, tell us the ZIP when we call.",
  },
  {
    q: "Are the parts genuine?",
    a: "We install the brand part or a named equivalent, and we say which one before it goes in.",
  },
  {
    q: "Can one visit cover two trades?",
    a: "Often yes — a water heater is both a plumber and an electrician. Book the louder problem. If a second trade is needed, we say so before sending another person.",
  },
  {
    q: "What about pets and kids during pest control?",
    a: "Gel work does not require anyone to leave. Sprayed rooms are aired, and we tell you how long to stay out — usually two hours, not the whole day.",
  },
];

export function tradeBySlug(slug: string): Trade | undefined {
  return trades.find((t) => t.slug === slug);
}
