import { ui } from "@/lib/content";

export function useI18n() {
  return { copy: ui };
}
