import { useEffect, useState, type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  ArrowRight,
  Droplets,
  Menu,
  Phone,
  SprayCan,
  WashingMachine,
  X,
  Zap,
} from "lucide-react";
import {
  DOMAIN,
  PHONE_DISPLAY,
  PHONE_TEL,
  cities,
  ticker,
  trades,
  type Trade,
} from "@/lib/content";
import { useI18n } from "@/lib/i18n";

export function tradeIcon(icon: Trade["icon"], className: string) {
  if (icon === "zap") return <Zap className={className} aria-hidden />;
  if (icon === "washer") return <WashingMachine className={className} aria-hidden />;
  if (icon === "drops") return <Droplets className={className} aria-hidden />;
  return <SprayCan className={className} aria-hidden />;
}

function Mark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden>
      <path
        d="M5 15.5 16 6l11 9.5"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinejoin="round"
      />
      <path
        d="M9 15.5V26h14V15.5"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinejoin="round"
      />
      <path d="M8 22h16" stroke="var(--color-copper)" strokeWidth="2.2" />
    </svg>
  );
}

export function Page({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-bg text-ink">
      <Ticker />
      <SiteHeader />
      {children}
      <SiteFooter />
      <MobileDock />
    </div>
  );
}

function Ticker() {
  const row = [...ticker, ...ticker];
  return (
    <div className="overflow-hidden bg-ink text-paper">
      <div className="ticker-track flex w-max">
        {[0, 1].map((copy) => (
          <p key={copy} className="flex shrink-0 items-center">
            {row.map((item, i) => (
              <span key={`${copy}-${i}`} className="px-5 py-2 text-sm whitespace-nowrap">
                <span className="me-5 inline-block size-1.5 translate-y-[-1px] rounded-full bg-copper" />
                {item}
              </span>
            ))}
          </p>
        ))}
      </div>
    </div>
  );
}

function SiteHeader() {
  const { copy } = useI18n();
  const path = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(false);

  useEffect(() => {
    setOpen(false);
  }, [path]);

  const links = [
    { to: "/", label: copy.home, active: path === "/" },
    { to: "/services", label: copy.services, active: path.startsWith("/services") },
    { to: "/offers", label: copy.offers, active: path.startsWith("/offers") },
  ] as const;

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-paper/95 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center gap-3 px-4">
        <Link to="/" className="flex items-center gap-2">
          <Mark className="size-9 text-ink" />
          <span className="leading-tight">
            <span className="block font-display text-xl text-ink">GharLine</span>
            <span className="block text-xs text-muted">{DOMAIN}</span>
          </span>
        </Link>

        <nav className="ms-6 hidden items-center gap-1 lg:flex">
          {links.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={`rounded-full px-3 py-2 text-sm font-medium ${
                item.active ? "bg-bg text-ink" : "text-muted hover:text-ink"
              }`}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="ms-auto flex items-center gap-2">
          <a
            href={`tel:${PHONE_TEL}`}
            className="hidden h-11 items-center gap-2 rounded-full border border-line px-3 text-sm font-semibold text-ink sm:inline-flex"
          >
            <Phone className="size-4" aria-hidden />
            <span dir="ltr">{PHONE_DISPLAY}</span>
          </a>
          <Link
            to="/book"
            search={{ service: "" }}
            className="inline-flex h-11 items-center gap-2 rounded-full bg-copper px-4 text-sm font-semibold text-paper hover:bg-copper-deep"
          >
            {copy.book}
          </Link>
          <button
            type="button"
            className="inline-flex size-11 items-center justify-center rounded-full border border-line lg:hidden"
            aria-expanded={open}
            aria-label={open ? copy.close : copy.menu}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
      </div>

      {open ? (
        <nav className="border-t border-line bg-paper px-4 py-3 lg:hidden">
          <div className="mx-auto flex max-w-6xl flex-col gap-1">
            {links.map((item) => (
              <Link key={item.to} to={item.to} className="flex min-h-12 items-center rounded-2xl px-3 text-lg">
                {item.label}
              </Link>
            ))}
            {trades.map((trade) => (
              <Link
                key={trade.slug}
                to="/services/$slug"
                params={{ slug: trade.slug }}
                className="flex min-h-12 items-center gap-3 rounded-2xl px-3 text-lg"
              >
                {tradeIcon(trade.icon, "size-5 text-copper")}
                {trade[lang].name}
              </Link>
            ))}
          </div>
        </nav>
      ) : null}
    </header>
  );
}

function MobileDock() {
  const { copy } = useI18n();
  return (
    <div className="fixed inset-x-0 bottom-0 z-40 flex gap-2 border-t border-line bg-paper p-3 lg:hidden">
      <a
        href={`tel:${PHONE_TEL}`}
        className="inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-full border border-line text-sm font-semibold"
      >
        <Phone className="size-4" aria-hidden />
        {copy.call}
      </a>
      <Link
        to="/book"
        search={{ service: "" }}
        className="inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-full bg-copper text-sm font-semibold text-paper"
      >
        {copy.book}
        <ArrowRight className="size-4 rtl:rotate-180" aria-hidden />
      </Link>
    </div>
  );
}

function SiteFooter() {
  const { copy } = useI18n();
  return (
    <footer className="border-t border-line bg-ink text-paper">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-14 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <p className="font-display text-2xl">GharLine</p>
          <p className="mt-1 text-sm text-copper" dir="ltr">
            {DOMAIN}
          </p>
          <p className="mt-4 text-sm text-paper/80">{copy.heroLede}</p>
        </div>
        <div>
          <p className="text-sm font-semibold text-copper">{copy.services}</p>
          <ul className="mt-3 space-y-2">
            {trades.map((trade) => (
              <li key={trade.slug}>
                <Link to="/services/$slug" params={{ slug: trade.slug }} className="text-sm hover:underline">
                  {trade.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <p className="text-sm font-semibold text-copper">{copy.coverageLabel}</p>
          <p className="mt-3 text-sm leading-6 text-paper/80">{cities.join(", ")}.</p>
        </div>
        <div>
          <p className="text-sm font-semibold text-copper">{copy.domainLine}</p>
          <a href={`tel:${PHONE_TEL}`} className="mt-3 block text-lg font-semibold" dir="ltr">
            {PHONE_DISPLAY}
          </a>
          <p className="mt-2 text-sm text-paper/80" dir="ltr">
            desk@gharline.com
          </p>
          <p className="mt-4 text-sm text-paper/70">{copy.confirmNote}</p>
        </div>
      </div>
      <div className="border-t border-paper/15">
        <p className="mx-auto max-w-6xl px-4 py-4 text-xs text-paper/60">
          © {new Date().getFullYear()} GharLine · {DOMAIN}
        </p>
      </div>
    </footer>
  );
}

export function Cta({
  to,
  children,
  tone = "copper",
  search,
}: {
  to: "/book" | "/offers" | "/services";
  children: ReactNode;
  tone?: "copper" | "paper" | "ghost";
  search?: { service: string };
}) {
  const className =
    tone === "copper"
      ? "inline-flex h-12 items-center justify-center gap-2 rounded-full bg-copper px-5 text-sm font-semibold text-paper hover:bg-copper-deep"
      : tone === "paper"
        ? "inline-flex h-12 items-center justify-center gap-2 rounded-full bg-paper px-5 text-sm font-semibold text-ink"
        : "inline-flex h-12 items-center justify-center gap-2 rounded-full border border-paper/30 px-5 text-sm font-semibold text-paper";
  if (to === "/book") {
    return (
      <Link to="/book" search={search ?? { service: "" }} className={className}>
        {children}
        <ArrowRight className="size-4 rtl:rotate-180" aria-hidden />
      </Link>
    );
  }
  return (
    <Link to={to} className={className}>
      {children}
      <ArrowRight className="size-4 rtl:rotate-180" aria-hidden />
    </Link>
  );
}
