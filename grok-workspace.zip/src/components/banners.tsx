import { Link } from "@tanstack/react-router";
import { ArrowRight, Check } from "lucide-react";
import { banners, trades, type Banner, type Trade } from "@/lib/content";
import { useI18n } from "@/lib/i18n";
import { Cta, tradeIcon } from "@/components/site-chrome";

export function Hero() {
  const { copy, lang } = useI18n();
  return (
    <section className="bg-ink text-paper lg:grid lg:min-h-hero lg:grid-cols-2">
      <div className="relative min-h-72 lg:min-h-full">
        <img
          src="/banners/hero.jpg"
          alt={lang === "en" ? "Electrician at a home breaker panel" : "گھر کے بریکر بورڈ پر الیکٹریشن"}
          width={1792}
          height={1008}
          className="absolute inset-0 h-full w-full object-cover"
        />
      </div>
      <div className="flex flex-col justify-center px-5 py-10 sm:px-10 lg:px-12 lg:py-16">
        <p className="text-sm font-semibold text-paper">{copy.heroKicker}</p>
        <span className="mt-4 block h-1 w-12 rounded-full bg-copper" />
        <h1 className="mt-4 max-w-xl font-display text-4xl text-paper sm:text-5xl lg:text-6xl">
          {copy.heroTitle}
        </h1>
        <p className="mt-4 max-w-xl text-lg text-paper/85">{copy.heroLede}</p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Cta to="/book">{copy.book}</Cta>
          <Cta to="/offers" tone="ghost">
            {copy.allBanners}
          </Cta>
        </div>
        <div className="mt-8 grid grid-cols-2 gap-2">
          {trades.map((trade) => (
            <Link
              key={trade.slug}
              to="/services/$slug"
              params={{ slug: trade.slug }}
              className="flex min-h-14 items-center gap-2 rounded-2xl bg-paper/10 px-3 py-2 text-sm font-semibold hover:bg-paper/15"
            >
              {tradeIcon(trade.icon, "size-4 shrink-0 text-paper")}
              <span>{trade[lang].name}</span>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}

export function StatBar() {
  const { copy } = useI18n();
  return (
    <section className="border-b border-line bg-paper">
      <dl className="mx-auto grid max-w-6xl grid-cols-2 md:grid-cols-4">
        {copy.stats.map((stat) => (
          <div key={stat.l} className="border-line px-5 py-5 md:border-s md:first:border-s-0">
            <dt className="font-display text-3xl tabular-nums text-ink">{stat.n}</dt>
            <dd className="mt-1 text-sm text-muted">{stat.l}</dd>
          </div>
        ))}
      </dl>
    </section>
  );
}

export function TradeCard({ trade }: { trade: Trade }) {
  const { lang, copy } = useI18n();
  const text = trade[lang];
  return (
    <Link
      to="/services/$slug"
      params={{ slug: trade.slug }}
      className="group flex flex-col overflow-hidden rounded-card border border-line bg-ink text-paper"
    >
      <div className="relative h-52 overflow-hidden sm:h-64">
        <img
          src={trade.image}
          alt=""
          className="h-full w-full object-cover motion-safe:transition motion-safe:duration-700 motion-safe:group-hover:scale-105"
        />
      </div>
      <div className="flex flex-1 flex-col p-5">
        <div className="flex items-center gap-2 text-sm font-semibold">
          {tradeIcon(trade.icon, "size-4")}
          {text.name}
        </div>
        <h3 className="mt-3 font-display text-2xl">{text.headline}</h3>
        <p className="mt-2 flex-1 text-sm text-paper/80">{text.short}</p>
        <p className="mt-4 text-sm font-semibold tabular-nums">
          {copy.from} {trade.from}
        </p>
      </div>
    </Link>
  );
}

export function BillBanner({ banner, flip = false }: { banner: Banner; flip?: boolean }) {
  const { lang, copy } = useI18n();
  const text = banner[lang];
  const service = banner.trade === "any" ? "" : banner.trade;
  return (
    <article className="grid overflow-hidden rounded-card border border-line bg-paper md:grid-cols-5">
      <div className={`relative min-h-banner md:col-span-2 ${flip ? "md:order-2" : ""}`}>
        <img src={banner.image} alt="" className="absolute inset-0 h-full w-full object-cover" />
      </div>
      <div className="flex flex-col justify-center gap-3 p-6 md:col-span-3 md:p-8">
        <p className="text-sm font-semibold text-copper">{text.kicker}</p>
        <h3 className="font-display text-3xl text-ink sm:text-4xl">{text.title}</h3>
        <p className="max-w-xl text-muted">{text.body}</p>
        <p className="font-display text-2xl tabular-nums text-ink">{banner.price}</p>
        <div>
          <Cta to="/book" search={{ service }}>
            {copy.book}
          </Cta>
        </div>
      </div>
    </article>
  );
}

export function BannerList({ items }: { items: Banner[] }) {
  return (
    <div className="flex flex-col gap-5">
      {items.map((banner, index) => (
        <BillBanner key={banner.id} banner={banner} flip={index % 2 === 1} />
      ))}
    </div>
  );
}

export function EmergencyBand() {
  const { copy } = useI18n();
  return (
    <section className="bg-bg">
      <div className="mx-auto grid max-w-6xl overflow-hidden rounded-card border border-line bg-ink text-paper lg:grid-cols-2">
        <div className="relative min-h-72">
          <img
            src="/banners/night.jpg"
            alt=""
            className="absolute inset-0 h-full w-full object-cover"
          />
        </div>
        <div className="flex flex-col justify-center p-6 sm:p-10">
          <p className="text-sm font-semibold">{copy.emergencyKicker}</p>
          <span className="mt-4 block h-1 w-12 rounded-full bg-copper" />
          <h2 className="mt-4 font-display text-3xl sm:text-4xl">{copy.emergencyTitle}</h2>
          <p className="mt-3 text-paper/80">{copy.emergencyBody}</p>
          <div className="mt-6">
            <Cta to="/book" search={{ service: "electrician" }}>
              {copy.book}
            </Cta>
          </div>
        </div>
      </div>
    </section>
  );
}

export function ClosingBand() {
  const { copy } = useI18n();
  return (
    <section className="bg-bg pb-24 lg:pb-16">
      <div className="mx-auto grid max-w-6xl items-center gap-6 overflow-hidden rounded-card bg-copper px-6 py-10 text-paper sm:px-10 lg:grid-cols-[1.4fr_auto]">
        <div>
          <h2 className="font-display text-3xl sm:text-5xl">{copy.closingTitle}</h2>
          <p className="mt-3 max-w-xl text-paper">{copy.closingBody}</p>
        </div>
        <Cta to="/book" tone="paper">
          {copy.book}
        </Cta>
      </div>
    </section>
  );
}

export function JobList({ jobs }: { jobs: string[] }) {
  return (
    <ul className="grid gap-3 sm:grid-cols-2">
      {jobs.map((job) => (
        <li key={job} className="flex items-start gap-3 rounded-2xl border border-line bg-paper px-4 py-3">
          <Check className="mt-0.5 size-4 shrink-0 text-copper" aria-hidden />
          <span>{job}</span>
        </li>
      ))}
    </ul>
  );
}

export function homeBanners() {
  return banners;
}

export function TradeStrip({ except }: { except?: string }) {
  const { lang, copy } = useI18n();
  const items = trades.filter((trade) => trade.slug !== except);
  return (
    <div>
      <h2 className="font-display text-3xl">{copy.otherTrades}</h2>
      <div className="mt-4 grid gap-3 sm:grid-cols-3">
        {items.map((trade) => (
          <Link
            key={trade.slug}
            to="/services/$slug"
            params={{ slug: trade.slug }}
            className="overflow-hidden rounded-card border border-line bg-paper"
          >
            <img src={trade.image} alt="" className="h-36 w-full object-cover" />
            <span className="flex items-center justify-between px-4 py-3 text-sm font-semibold">
              {trade[lang].name}
              <ArrowRight className="size-4 rtl:rotate-180" aria-hidden />
            </span>
          </Link>
        ))}
      </div>
    </div>
  );
}
