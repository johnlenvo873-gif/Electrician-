import { useEffect, useState, type FormEvent } from "react";
import { cities, slots, trades, type TradeSlug } from "@/lib/content";
import { useI18n } from "@/lib/i18n";

const STORAGE_KEY = "gharline-requests";

type RequestRow = {
  ticket: string;
  name: string;
  phone: string;
  city: string;
  service: string;
  when: string;
  note: string;
  at: string;
};

function readRows(): RequestRow[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as RequestRow[];
    return Array.isArray(parsed) ? parsed.slice(0, 6) : [];
  } catch {
    return [];
  }
}

export function BookingForm({ initialService = "" }: { initialService?: string }) {
  const { lang, copy } = useI18n();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [city, setCity] = useState("");
  const [service, setService] = useState(initialService);
  const [when, setWhen] = useState(slots[0].en);
  const [note, setNote] = useState("");
  const [error, setError] = useState("");
  const [ticket, setTicket] = useState("");
  const [rows, setRows] = useState<RequestRow[]>([]);

  useEffect(() => {
    setRows(readRows());
  }, []);

  useEffect(() => {
    if (initialService) setService(initialService);
  }, [initialService]);

  const field =
    "h-12 w-full rounded-2xl border border-line bg-paper px-4 text-ink outline-none";

  function submit(event: FormEvent) {
    event.preventDefault();
    if (name.trim().length < 2) return setError(copy.needName);
    if (!/^(?:\+?92|0)?3\d{9}$/.test(phone.replace(/[\s-]/g, ""))) return setError(copy.needPhone);
    if (!city) return setError(copy.needCity);
    if (!trades.some((trade) => trade.slug === service)) return setError(copy.needService);
    if (note.trim().length < 8) return setError(copy.needNote);

    const next: RequestRow = {
      ticket: `GL-${Math.floor(10000 + Math.random() * 89999)}`,
      name: name.trim(),
      phone: phone.trim(),
      city,
      service,
      when,
      note: note.trim(),
      at: new Date().toISOString(),
    };
    const saved = [next, ...readRows()].slice(0, 6);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(saved));
    setRows(saved);
    setTicket(next.ticket);
    setError("");
  }

  if (ticket) {
    const trade = trades.find((item) => item.slug === (service as TradeSlug));
    return (
      <div role="status" className="rounded-card border border-line bg-paper p-6 sm:p-8">
        <p className="text-sm font-semibold text-copper">{copy.ticket}</p>
        <h2 className="mt-2 font-display text-4xl">{copy.successTitle}</h2>
        <p className="mt-3 font-display text-3xl tabular-nums" dir="ltr">
          {ticket}
        </p>
        <p className="mt-4 text-muted">{copy.confirmNote}</p>
        <dl className="mt-6 grid gap-3 text-sm sm:grid-cols-2">
          <div>
            <dt className="text-muted">{copy.name}</dt>
            <dd className="font-semibold">{name}</dd>
          </div>
          <div>
            <dt className="text-muted">{copy.phone}</dt>
            <dd className="font-semibold" dir="ltr">
              {phone}
            </dd>
          </div>
          <div>
            <dt className="text-muted">{copy.city}</dt>
            <dd className="font-semibold">{cities.find((item) => item.en === city)?.[lang] ?? city}</dd>
          </div>
          <div>
            <dt className="text-muted">{copy.service}</dt>
            <dd className="font-semibold">{trade ? trade[lang].name : service}</dd>
          </div>
        </dl>
        <p className="mt-6 text-sm text-muted">{copy.onDevice}</p>
        <button
          type="button"
          className="mt-4 inline-flex h-11 items-center rounded-full border border-line px-4 text-sm font-semibold"
          onClick={() => {
            setTicket("");
            setNote("");
          }}
        >
          {copy.book}
        </button>
      </div>
    );
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1.4fr_0.8fr]">
      <form onSubmit={submit} className="rounded-card border border-line bg-paper p-5 sm:p-8" noValidate>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block text-sm font-semibold">
            {copy.name}
            <input className={`${field} mt-2`} value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" />
          </label>
          <label className="block text-sm font-semibold">
            {copy.phone}
            <input
              className={`${field} mt-2`}
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              autoComplete="tel"
              inputMode="tel"
              dir="ltr"
              placeholder="03xx xxx xxxx"
            />
          </label>
          <label className="block text-sm font-semibold">
            {copy.city}
            <select className={`${field} mt-2`} value={city} onChange={(e) => setCity(e.target.value)}>
              <option value="">{copy.choose}</option>
              {cities.map((item) => (
                <option key={item.en} value={item.en}>
                  {item[lang]}
                </option>
              ))}
            </select>
          </label>
          <label className="block text-sm font-semibold">
            {copy.service}
            <select className={`${field} mt-2`} value={service} onChange={(e) => setService(e.target.value)}>
              <option value="">{copy.choose}</option>
              {trades.map((trade) => (
                <option key={trade.slug} value={trade.slug}>
                  {trade[lang].name}
                </option>
              ))}
            </select>
          </label>
          <label className="block text-sm font-semibold sm:col-span-2">
            {copy.when}
            <select className={`${field} mt-2`} value={when} onChange={(e) => setWhen(e.target.value)}>
              {slots.map((slot) => (
                <option key={slot.en} value={slot.en}>
                  {slot[lang]}
                </option>
              ))}
            </select>
          </label>
          <label className="block text-sm font-semibold sm:col-span-2">
            {copy.note}
            <textarea
              className="mt-2 min-h-32 w-full rounded-2xl border border-line bg-paper px-4 py-3 text-ink outline-none"
              value={note}
              onChange={(e) => setNote(e.target.value)}
            />
          </label>
        </div>
        {error ? (
          <p role="alert" className="mt-4 text-sm font-semibold text-copper">
            {error}
          </p>
        ) : null}
        <p className="mt-4 text-sm text-muted">{copy.visitNote}</p>
        <button
          type="submit"
          className="mt-5 inline-flex h-12 items-center rounded-full bg-copper px-6 text-sm font-semibold text-paper hover:bg-copper-deep"
        >
          {copy.submit}
        </button>
      </form>

      <aside className="rounded-card border border-line bg-ink p-5 text-paper sm:p-6">
        <h2 className="font-display text-2xl">{copy.recent}</h2>
        {rows.length === 0 ? (
          <p className="mt-3 text-sm text-paper/75">{copy.onDevice}</p>
        ) : (
          <ul className="mt-4 space-y-3">
            {rows.map((row) => (
              <li key={row.ticket} className="rounded-2xl bg-paper/10 px-3 py-3">
                <p className="text-sm font-semibold tabular-nums" dir="ltr">
                  {row.ticket}
                </p>
                <p className="text-sm text-paper/80">
                  {trades.find((trade) => trade.slug === row.service)?.[lang].name ?? row.service}
                  {" · "}
                  {cities.find((item) => item.en === row.city)?.[lang] ?? row.city}
                </p>
              </li>
            ))}
          </ul>
        )}
      </aside>
    </div>
  );
}
