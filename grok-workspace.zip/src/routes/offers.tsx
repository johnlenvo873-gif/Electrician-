import { createFileRoute } from "@tanstack/react-router";
import { banners } from "@/lib/content";
import { useI18n } from "@/lib/i18n";
import { Page } from "@/components/site-chrome";
import { BannerList } from "@/components/banners";

export const Route = createFileRoute("/offers")({
  head: () => ({
    meta: [
      { title: "Banners & offers · GharLine.com" },
      {
        name: "description",
        content:
          "Live banners for electrician, appliance, plumber, and pest control visits on GharLine.com.",
      },
    ],
  }),
  component: OffersPage,
});

function OffersPage() {
  const { copy } = useI18n();
  return (
    <Page>
      <main className="mx-auto max-w-6xl px-4 py-12 pb-28">
        <p className="text-sm font-semibold text-copper">gharline.com</p>
        <h1 className="mt-3 max-w-3xl font-display text-4xl sm:text-6xl">{copy.allBanners}</h1>
        <p className="mt-4 max-w-2xl text-lg text-muted">{copy.bannerLede}</p>
        <div className="mt-10">
          <BannerList items={banners} />
        </div>
      </main>
    </Page>
  );
}
