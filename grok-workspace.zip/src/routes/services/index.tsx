import { createFileRoute } from "@tanstack/react-router";
import { trades } from "@/lib/content";
import { useI18n } from "@/lib/i18n";
import { Page } from "@/components/site-chrome";
import { TradeCard } from "@/components/banners";

export const Route = createFileRoute("/services/")({
  head: () => ({
    meta: [
      { title: "Services · GharLine.com" },
      {
        name: "description",
        content: "Electrician, appliance repair, plumber, and pest control from GharLine.com.",
      },
    ],
  }),
  component: ServicesHome,
});

function ServicesHome() {
  const { copy } = useI18n();
  return (
    <Page>
      <main className="mx-auto max-w-6xl px-4 py-12 pb-28">
        <p className="text-sm font-semibold text-copper">gharline.com</p>
        <h1 className="mt-3 max-w-3xl font-display text-4xl sm:text-6xl">{copy.servicesTitle}</h1>
        <p className="mt-4 max-w-2xl text-lg text-muted">{copy.servicesLede}</p>
        <div className="mt-10 grid gap-4 md:grid-cols-2">
          {trades.map((trade) => (
            <TradeCard key={trade.slug} trade={trade} />
          ))}
        </div>
      </main>
    </Page>
  );
}
