import { createFileRoute, Link } from "@tanstack/react-router";
import { banners, tradeBySlug } from "@/lib/content";
import { useI18n } from "@/lib/i18n";
import { Page } from "@/components/site-chrome";
import { BannerList, JobList, TradeStrip } from "@/components/banners";

export const Route = createFileRoute("/services/$slug")({
  head: ({ params }) => {
    const trade = tradeBySlug(params.slug);
    const name = trade?.en.name ?? "Service";
    return {
      meta: [
        { title: `${name} · GharLine.com` },
        {
          name: "description",
          content: trade?.en.lede ?? "Home repair on GharLine.com",
        },
      ],
    };
  },
  component: TradePage,
});

function TradePage() {
  const { slug } = Route.useParams();
  const { lang, copy } = useI18n();
  const trade = tradeBySlug(slug);

  if (!trade) {
    return (
      <Page>
        <main className="mx-auto max-w-xl px-4 py-24 text-center">
          <h1 className="font-display text-4xl">{copy.notFoundTitle}</h1>
          <p className="mt-3 text-muted">{copy.notFoundBody}</p>
          <Link
            to="/services"
            className="mt-6 inline-flex h-12 items-center rounded-full bg-copper px-5 font-semibold text-paper"
          >
            {copy.services}
          </Link>
        </main>
      </Page>
    );
  }

  const text = trade[lang];
  const related = banners.filter((banner) => banner.trade === trade.slug);

  return (
    <Page>
      <main className="pb-24">
        <section className="bg-ink text-paper lg:grid lg:grid-cols-2">
          <div className="relative min-h-72">
            <img src={trade.image} alt="" className="absolute inset-0 h-full w-full object-cover" />
          </div>
          <div className="flex flex-col justify-center px-5 py-10 sm:px-10">
            <p className="text-sm font-semibold">{text.name}</p>
            <span className="mt-4 block h-1 w-12 rounded-full bg-copper" />
            <h1 className="mt-4 font-display text-4xl sm:text-5xl">{text.headline}</h1>
            <p className="mt-4 max-w-xl text-lg text-paper/80">{text.lede}</p>
            <p className="mt-4 font-display text-3xl tabular-nums">
              {copy.from} {trade.from}
            </p>
            <p className="mt-2 text-sm text-paper/70">{copy.priceNote}</p>
            <Link
              to="/book"
              search={{ service: trade.slug }}
              className="mt-6 inline-flex h-12 w-fit items-center rounded-full bg-copper px-5 font-semibold text-paper hover:bg-copper-deep"
            >
              {copy.bookThis}
            </Link>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-4 py-12">
          <h2 className="font-display text-3xl">{copy.included}</h2>
          <div className="mt-6">
            <JobList jobs={text.jobs} />
          </div>
        </section>

        {related.length > 0 ? (
          <section className="mx-auto max-w-6xl px-4 pb-12">
            <h2 className="mb-6 font-display text-3xl">{copy.related}</h2>
            <BannerList items={related} />
          </section>
        ) : null}

        <section className="mx-auto max-w-6xl px-4 pb-4">
          <TradeStrip except={trade.slug} />
        </section>
      </main>
    </Page>
  );
}
