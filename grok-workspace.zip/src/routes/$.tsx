import { createFileRoute, Link } from "@tanstack/react-router";
import { useI18n } from "@/lib/i18n";
import { Page } from "@/components/site-chrome";

export const Route = createFileRoute("/$")({
  component: Missing,
});

function Missing() {
  const { copy } = useI18n();
  return (
    <Page>
      <main className="mx-auto max-w-xl px-4 py-24 pb-32 text-center">
        <h1 className="font-display text-4xl">{copy.notFoundTitle}</h1>
        <p className="mt-3 text-muted">{copy.notFoundBody}</p>
        <Link
          to="/"
          className="mt-6 inline-flex h-12 items-center rounded-full bg-copper px-5 font-semibold text-paper"
        >
          {copy.backHome}
        </Link>
      </main>
    </Page>
  );
}
