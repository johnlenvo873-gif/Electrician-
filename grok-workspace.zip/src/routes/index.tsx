import { createFileRoute } from "@tanstack/react-router";
import { ChevronDown } from "lucide-react";
import { banners, cities, faqs, reviews, trades } from "@/lib/content";
import { useI18n } from "@/lib/i18n";
import { Page } from "@/components/site-chrome";
import {
  BannerList,
  ClosingBand,
  EmergencyBand,
  Hero,
  StatBar,
  TradeCard,
} from "@/components/banners";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "GharLine.com — Electrician, Appliance, Plumber, Pest Control" },
      {
        name: "description",
        content:
          "A large home-services desk for electrician repair, appliance repair, plumbing, and pest control. Book a visit on GharLine.com.",
      },
    ],
  }),
  component: Home,
});

function Home() {
  const { lang, copy } = useI18n();
  return (
    <Page>
      <main>
        <Hero />
        <StatBar />

        <section className="mx-auto max-w-6xl px-4 py-14">
          <h2 className="max-w-2xl font-display text-4xl sm:text-5xl">{copy.servicesTitle}</h2>
          <p className="mt-3 max-w-2xl text-muted">{copy.servicesLede}</p>
          <div className="mt-8 grid gap-4 md:grid-cols-2">
            {trades.map((trade) => (
              <TradeCard key={trade.slug} trade={trade} />
            ))}
          </div>
        </section>

        <section className="bg-bg pb-6">
          <div className="mx-auto max-w-6xl px-4">
            <EmergencyBand />
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-4 py-14">
          <div className="mb-8 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <h2 className="font-display text-4xl sm:text-5xl">{copy.allBanners}</h2>
              <p className="mt-3 max-w-2xl text-muted">{copy.bannerLede}</p>
            </div>
          </div>
          <BannerList items={banners} />
        </section>

        <section className="border-y border-line bg-paper">
          <div className="mx-auto max-w-6xl px-4 py-14">
            <h2 className="font-display text-4xl">{copy.howTitle}</h2>
            <p className="mt-3 max-w-2xl text-muted">{copy.howLede}</p>
            <ol className="mt-8 grid gap-4 md:grid-cols-3">
              {copy.steps.map((step, index) => (
                <li key={step.t} className="rounded-card border border-line bg-bg p-5">
                  <p className="font-display text-3xl tabular-nums text-copper">0{index + 1}</p>
                  <h3 className="mt-3 text-2xl">{step.t}</h3>
                  <p className="mt-2 text-muted">{step.d}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        <section className="mx-auto grid max-w-6xl gap-8 px-4 py-14 lg:grid-cols-2">
          <div className="overflow-hidden rounded-card">
            <img
              src="/banners/wiring.jpg"
              alt={lang === "en" ? "Neat electrical wiring inside a breaker box" : "بریکر باکس میں صاف وائرنگ"}
              className="h-full max-h-[32rem] w-full object-cover"
            />
          </div>
          <div>
            <h2 className="font-display text-4xl">{copy.promiseTitle}</h2>
            <ul className="mt-6 space-y-4">
              {copy.promises.map((item) => (
                <li key={item.t} className="border-b border-line pb-4">
                  <p className="font-semibold">{item.t}</p>
                  <p className="mt-1 text-muted">{item.d}</p>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section className="bg-ink text-paper">
          <div className="mx-auto grid max-w-6xl gap-8 px-4 py-14 lg:grid-cols-[0.8fr_1.2fr] lg:items-center">
            <div>
              <h2 className="font-display text-4xl">{copy.citiesTitle}</h2>
              <p className="mt-3 text-paper/75">{copy.citiesLede}</p>
            </div>
            <ul className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {cities.map((city) => (
                <li key={city.en} className="rounded-2xl bg-paper/10 px-3 py-4 text-center font-semibold">
                  {city[lang]}
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-4 py-14">
          <h2 className="font-display text-4xl">{copy.reviewsTitle}</h2>
          <div className="mt-8 grid gap-4 lg:grid-cols-3">
            {reviews.map((review) => (
              <figure key={review.en.n} className="rounded-card border border-line bg-paper p-5">
                <blockquote className="text-lg">{review[lang].q}</blockquote>
                <figcaption className="mt-4 text-sm text-muted">
                  <span className="block font-semibold text-ink">{review[lang].n}</span>
                  {review[lang].m}
                </figcaption>
              </figure>
            ))}
          </div>
        </section>

        <section className="mx-auto max-w-3xl px-4 pb-14">
          <h2 className="font-display text-4xl">{copy.faqTitle}</h2>
          <div className="mt-6 border-t border-line">
            {faqs.map((item) => (
              <details key={item.en.q} className="group border-b border-line py-4">
                <summary className="flex cursor-pointer items-center justify-between gap-4 text-lg font-semibold">
                  {item[lang].q}
                  <ChevronDown className="size-5 shrink-0 text-copper motion-safe:transition group-open:rotate-180" />
                </summary>
                <p className="mt-3 text-muted">{item[lang].a}</p>
              </details>
            ))}
          </div>
        </section>

        <ClosingBand />
      </main>
    </Page>
  );
}
