import { createFileRoute } from "@tanstack/react-router";
import { trades } from "@/lib/content";
import { useI18n } from "@/lib/i18n";
import { Page } from "@/components/site-chrome";
import { BookingForm } from "@/components/booking-form";

type BookSearch = { service: string };

export const Route = createFileRoute("/book")({
  validateSearch: (search: Record<string, unknown>): BookSearch => {
    const service = typeof search.service === "string" ? search.service : "";
    return {
      service: trades.some((trade) => trade.slug === service) ? service : "",
    };
  },
  head: () => ({
    meta: [
      { title: "Book a visit · GharLine.com" },
      {
        name: "description",
        content: "Request an electrician, appliance tech, plumber, or pest control visit from GharLine.com.",
      },
    ],
  }),
  component: BookPage,
});

function BookPage() {
  const { service } = Route.useSearch();
  const { copy } = useI18n();
  return (
    <Page>
      <main className="mx-auto max-w-6xl px-4 py-12 pb-28">
        <div className="grid items-end gap-6 lg:grid-cols-[1.1fr_0.9fr]">
          <div>
            <p className="text-sm font-semibold text-copper">gharline.com</p>
            <h1 className="mt-3 font-display text-4xl sm:text-6xl">{copy.book}</h1>
            <p className="mt-4 max-w-xl text-lg text-muted">{copy.closingBody}</p>
          </div>
          <img
            src="/banners/ac.jpg"
            alt=""
            className="h-48 w-full rounded-card object-cover lg:h-56"
          />
        </div>
        <div className="mt-8">
          <BookingForm initialService={service} />
        </div>
      </main>
    </Page>
  );
}
